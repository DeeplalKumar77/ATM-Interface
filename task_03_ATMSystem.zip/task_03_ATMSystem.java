import java.util.Scanner;

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        if (initialBalance < 0) {
            initialBalance = 0;
        }
        this.balance = initialBalance;
    }

    public double getBalance() {
        return balance;
    }

    public String deposit(double amount) {
        if (amount <= 0) {
            return "Deposit amount must be positive.";
        }
        balance += amount;
        return String.format("Deposited $%.2f successfully.", amount);
    }

    public String withdraw(double amount) {
        if (amount <= 0) {
            return "Withdrawal amount must be positive.";
        }
        if (amount > balance) {
            return "Insufficient balance.";
        }
        balance -= amount;
        return String.format("Withdrew $%.2f successfully.", amount);
    }
}

class ATM {
    private BankAccount account;
    private Scanner scanner;

    public ATM(BankAccount account) {
        this.account = account;
        this.scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        System.out.println("\n--- ATM Menu ---");
        System.out.println("1. Check Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Exit");
    }

    public void run() {
        boolean running = true;
        while (running) {
            displayMenu();
            System.out.print("Choose an option (1-4): ");
            String input = scanner.nextLine();

            switch (input) {
                case "1":
                    System.out.printf("Your current balance is: $%.2f%n", account.getBalance());
                    break;
                case "2":
                    Double depositAmount = getAmount("deposit");
                    if (depositAmount != null) {
                        String message = account.deposit(depositAmount);
                        System.out.println(message);
                    }
                    break;
                case "3":
                    Double withdrawAmount = getAmount("withdraw");
                    if (withdrawAmount != null) {
                        String message = account.withdraw(withdrawAmount);
                        System.out.println(message);
                    }
                    break;
                case "4":
                    System.out.println("Thank you for using the ATM. Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please choose a number between 1 and 4.");
            }
        }
    }

    private Double getAmount(String action) {
        System.out.printf("Enter amount to %s: ", action);
        String input = scanner.nextLine();
        try {
            double amount = Double.parseDouble(input);
            if (amount <= 0) {
                System.out.println("Amount must be greater than zero.");
                return null;
            }
            return amount;
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a numeric value.");
            return null;
        }
    }
}

public class task_03_ATMSystem {
    public static void main(String[] args) {
        BankAccount userAccount = new BankAccount(1000); // Starting with $1000 balance
        ATM atmMachine = new ATM(userAccount);
        atmMachine.run();
    }
}